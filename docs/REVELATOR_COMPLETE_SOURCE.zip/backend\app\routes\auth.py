"""
Authentication routes: register, login, refresh, me, Google OAuth.
"""

from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User, UserApiKey, LoginCode, TrustedDevice
from ..auth import (
    hash_password, verify_password,
    create_access_token, create_refresh_token, create_verification_token,
    create_signup_token, create_reset_token, decode_token, get_current_user,
    generate_otp_code, generate_device_token, hash_token,
)
from ..config import (
    GOOGLE_CLIENT_ID, FRONTEND_URL,
    TWO_FACTOR_ENABLED, TWO_FACTOR_CODE_TTL_MINUTES, TWO_FACTOR_MAX_ATTEMPTS,
    TRUSTED_DEVICE_DAYS,
)
from ..email_utils import send_verification_email, send_reset_email, send_2fa_code_email, _smtp_configured

router = APIRouter(prefix="/api/auth", tags=["auth"])


# ── Request / Response schemas ──────────────────────────

class RegisterRequest(BaseModel):
    email: str
    username: str
    password: str
    full_name: str = ""

class LoginRequest(BaseModel):
    email: str
    password: str
    device_token: str | None = None  # remembered-device token, skips 2FA when valid


class Verify2FARequest(BaseModel):
    email: str
    code: str
    remember_device: bool = False


class Toggle2FARequest(BaseModel):
    enabled: bool

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: dict

class RefreshRequest(BaseModel):
    refresh_token: str

class UserResponse(BaseModel):
    id: str
    email: str
    username: str
    full_name: str
    scans_this_month: int
    created_at: str

class GoogleAuthRequest(BaseModel):
    id_token: str

class RegisterResponse(BaseModel):
    message: str
    email: str
    verification_required: bool = True

class ResendRequest(BaseModel):
    email: str

class ForgotPasswordRequest(BaseModel):
    email: str

class ResetPasswordRequest(BaseModel):
    token: str
    password: str


def user_to_dict(user: User, db: Session = None) -> dict:
    role_name = user.role or "user"
    return {
        "id": user.id,
        "email": user.email,
        "username": user.username,
        "full_name": user.full_name or "",
        "scans_this_month": user.scans_this_month,
        "role": role_name,
        "is_active": bool(user.is_active),
        "two_factor_enabled": bool(user.two_factor_enabled) if user.two_factor_enabled is not None else True,
        "created_at": user.created_at.isoformat() if user.created_at else "",
    }


# ── Two-factor helpers ──────────────────────────────────

def _issue_login(user: User, db: Session, device_token: str | None = None) -> dict:
    """Build the standard authenticated response (tokens + user)."""
    resp = {
        "requires_2fa": False,
        "access_token": create_access_token(user.id),
        "refresh_token": create_refresh_token(user.id),
        "token_type": "bearer",
        "user": user_to_dict(user, db),
    }
    if device_token:
        resp["device_token"] = device_token
    return resp


def _device_is_trusted(user: User, device_token: str | None, db: Session) -> bool:
    """True if this remembered-device token is valid and unexpired for the user."""
    if not device_token:
        return False
    dev = (
        db.query(TrustedDevice)
        .filter(TrustedDevice.user_id == user.id,
                TrustedDevice.token_hash == hash_token(device_token))
        .first()
    )
    if not dev:
        return False
    if dev.expires_at and dev.expires_at < datetime.utcnow():
        db.delete(dev)
        db.commit()
        return False
    dev.last_used_at = datetime.utcnow()
    db.commit()
    return True


def _send_login_code(user: User, db: Session) -> bool:
    """Issue a fresh 6-digit code (replacing any prior one) and email it.

    Returns whether the email was actually sent."""
    db.query(LoginCode).filter(LoginCode.user_id == user.id).delete()
    code = generate_otp_code()
    db.add(LoginCode(
        user_id=user.id,
        code_hash=hash_token(code),
        expires_at=datetime.utcnow() + timedelta(minutes=TWO_FACTOR_CODE_TTL_MINUTES),
        attempts=0,
    ))
    db.commit()
    return send_2fa_code_email(user.email, code, TWO_FACTOR_CODE_TTL_MINUTES)


def _twofa_required_for(user: User) -> bool:
    """Whether a password login for this user must pass the email-code step.

    Gated on the global flag, the per-user opt-in, that the account actually has
    a password (Google-only accounts are exempt), and that email can be sent at
    all (never lock a user out when SMTP is down)."""
    return bool(
        TWO_FACTOR_ENABLED
        and user.two_factor_enabled
        and user.hashed_password
        and _smtp_configured()
    )


# ── Endpoints ───────────────────────────────────────────

@router.post("/register")
def register(body: RegisterRequest, db: Session = Depends(get_db)):
    from ..config import REQUIRE_EMAIL_VERIFICATION
    if len(body.password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters")

    # An identifier is only "taken" once it belongs to a *verified* account.
    # Any unverified row found here is a stale leftover (from the old flow, or
    # from this user themselves never finishing); reclaim it so they can re-register.
    existing_email = db.query(User).filter(User.email == body.email).first()
    if existing_email:
        if existing_email.is_verified:
            raise HTTPException(status_code=400, detail="Email already registered")
        db.delete(existing_email)
        db.commit()

    existing_username = db.query(User).filter(User.username == body.username).first()
    if existing_username:
        if existing_username.is_verified:
            raise HTTPException(status_code=400, detail="Username already taken")
        db.delete(existing_username)
        db.commit()

    # Free / laptop-hosted deployments: skip the email round-trip, create a
    # verified account now, and return tokens so the client auto-logs in.
    if not REQUIRE_EMAIL_VERIFICATION:
        user = User(
            email=body.email,
            username=body.username,
            hashed_password=hash_password(body.password),
            full_name=body.full_name or "",
            is_verified=True,
            scans_this_month=0,
            scan_reset_date=datetime.utcnow(),
        )
        db.add(user)
        db.commit()
        return {
            "access_token": create_access_token(user.id),
            "refresh_token": create_refresh_token(user.id),
            "user": user_to_dict(user, db),
        }

    # Verification required: stateless signup - no user row is created here. The
    # registration payload is encoded into the verification token; the row is
    # only inserted when the link in the email is clicked.
    token = create_signup_token(
        email=body.email,
        username=body.username,
        hashed_password=hash_password(body.password),
        full_name=body.full_name,
    )
    send_verification_email(body.email, token)

    return {
        "message": "Check your email to confirm your address. Your account is created once you click the link.",
        "email": body.email,
    }


@router.post("/login")
def login(body: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email).first()
    if not user or not verify_password(body.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account disabled")
    if not user.is_verified:
        raise HTTPException(status_code=403, detail="Please verify your email before signing in. Check your inbox or request a new link.")

    # A remembered device skips the code entirely.
    if _device_is_trusted(user, body.device_token, db):
        return _issue_login(user, db)

    # Otherwise, if 2FA applies, email a code and pause; the client finishes at
    # /verify-2fa. If the send fails we fall through and log them in rather than
    # trap them behind a code they never receive.
    if _twofa_required_for(user):
        if _send_login_code(user, db):
            return {
                "requires_2fa": True,
                "email": user.email,
                "message": f"We emailed a 6-digit code to {user.email}. Enter it to finish signing in.",
            }

    return _issue_login(user, db)


@router.post("/verify-2fa")
def verify_2fa(body: Verify2FARequest, db: Session = Depends(get_db)):
    """Finish a 2FA login by confirming the emailed 6-digit code."""
    user = db.query(User).filter(User.email == body.email).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Invalid or expired code")

    rec = (
        db.query(LoginCode)
        .filter(LoginCode.user_id == user.id)
        .order_by(LoginCode.created_at.desc())
        .first()
    )
    if not rec:
        raise HTTPException(status_code=401, detail="No sign-in code is pending. Please sign in again.")

    if rec.expires_at < datetime.utcnow():
        db.delete(rec)
        db.commit()
        raise HTTPException(status_code=401, detail="That code has expired. Request a new one.")

    if rec.attempts >= TWO_FACTOR_MAX_ATTEMPTS:
        db.delete(rec)
        db.commit()
        raise HTTPException(status_code=429, detail="Too many attempts. Please sign in again for a new code.")

    code = (body.code or "").strip().replace(" ", "")
    if hash_token(code) != rec.code_hash:
        rec.attempts += 1
        db.commit()
        remaining = max(0, TWO_FACTOR_MAX_ATTEMPTS - rec.attempts)
        raise HTTPException(status_code=401, detail=f"Incorrect code. {remaining} attempt(s) left.")

    # Correct: consume every pending code for this user.
    db.query(LoginCode).filter(LoginCode.user_id == user.id).delete()

    device_token = None
    if body.remember_device:
        device_token = generate_device_token()
        db.add(TrustedDevice(
            user_id=user.id,
            token_hash=hash_token(device_token),
            expires_at=datetime.utcnow() + timedelta(days=TRUSTED_DEVICE_DAYS),
            last_used_at=datetime.utcnow(),
        ))
    db.commit()

    return _issue_login(user, db, device_token=device_token)


@router.post("/resend-2fa")
def resend_2fa(body: ResendRequest, db: Session = Depends(get_db)):
    """Re-send the login code. Always 200 so accounts can't be enumerated."""
    user = db.query(User).filter(User.email == body.email).first()
    if user and user.is_active and user.is_verified and _twofa_required_for(user):
        _send_login_code(user, db)
    return {"message": "If a sign-in is in progress, a new code has been sent."}


@router.put("/2fa")
def set_two_factor(
    body: Toggle2FARequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Turn email 2FA on or off for the signed-in account."""
    current_user.two_factor_enabled = bool(body.enabled)
    if not body.enabled:
        db.query(LoginCode).filter(LoginCode.user_id == current_user.id).delete()
    db.commit()
    return {"success": True, "two_factor_enabled": bool(current_user.two_factor_enabled)}


@router.post("/refresh", response_model=TokenResponse)
def refresh_token(body: RefreshRequest, db: Session = Depends(get_db)):
    payload = decode_token(body.refresh_token)
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    user = db.query(User).filter(User.id == payload["sub"]).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User not found")

    return TokenResponse(
        access_token=create_access_token(user.id),
        refresh_token=create_refresh_token(user.id),
        user=user_to_dict(user, db),
    )


@router.get("/verify-email")
def verify_email(token: str, db: Session = Depends(get_db)):
    """Confirm an email address from the link we sent.

    Two token shapes are accepted:
      - `signup`: stateless - the registration payload is in the token; create
        the user row now and mark it verified.
      - `verify`: legacy - token references an existing unverified row by id.
        Kept for any in-flight links from before the stateless flow shipped.
    """
    payload = decode_token(token)
    if not payload:
        return RedirectResponse(url=f"{FRONTEND_URL}/login?verified=0")

    token_type = payload.get("type")

    if token_type == "signup":
        email = payload.get("email")
        username = payload.get("username")
        hashed_password = payload.get("hashed_password")
        full_name = payload.get("full_name", "") or ""

        if not email or not username or not hashed_password:
            return RedirectResponse(url=f"{FRONTEND_URL}/login?verified=0")

        # Re-check uniqueness now that we're actually creating the row.
        # Reclaim any stale unverified row owning the same identifier.
        existing_email = db.query(User).filter(User.email == email).first()
        if existing_email:
            if existing_email.is_verified:
                return RedirectResponse(url=f"{FRONTEND_URL}/login?verified=0")
            db.delete(existing_email)
            db.commit()

        existing_username = db.query(User).filter(User.username == username).first()
        if existing_username:
            if existing_username.is_verified:
                return RedirectResponse(url=f"{FRONTEND_URL}/login?verified=0")
            db.delete(existing_username)
            db.commit()

        user = User(
            email=email,
            username=username,
            hashed_password=hashed_password,
            full_name=full_name,
            is_verified=True,
            scans_this_month=0,
            scan_reset_date=datetime.utcnow(),
        )
        db.add(user)
        db.commit()
        return RedirectResponse(url=f"{FRONTEND_URL}/login?verified=1")

    if token_type == "verify":
        user = db.query(User).filter(User.id == payload["sub"]).first()
        if not user:
            return RedirectResponse(url=f"{FRONTEND_URL}/login?verified=0")
        if not user.is_verified:
            user.is_verified = True
            db.commit()
        return RedirectResponse(url=f"{FRONTEND_URL}/login?verified=1")

    return RedirectResponse(url=f"{FRONTEND_URL}/login?verified=0")


@router.post("/resend-verification")
def resend_verification(body: ResendRequest, db: Session = Depends(get_db)):
    """Send a fresh verification link. Always returns success to avoid leaking which emails exist."""
    user = db.query(User).filter(User.email == body.email).first()
    if user and not user.is_verified and user.hashed_password:
        user.verification_sent_at = datetime.utcnow()
        db.commit()
        send_verification_email(user.email, create_verification_token(user.id))
    return {"message": "If that account needs verification, a new link has been sent."}


@router.post("/forgot-password")
def forgot_password(body: ForgotPasswordRequest, db: Session = Depends(get_db)):
    """Email a password-reset link. Always returns success so emails can't be enumerated."""
    user = db.query(User).filter(User.email == body.email).first()
    # Only password accounts can reset; Google-only accounts have no password to change.
    if user and user.hashed_password:
        send_reset_email(user.email, create_reset_token(user.id))
    return {"message": "If an account exists for that email, a reset link has been sent."}


@router.post("/reset-password")
def reset_password(body: ResetPasswordRequest, db: Session = Depends(get_db)):
    """Set a new password using a valid reset token from the emailed link."""
    payload = decode_token(body.token)
    if not payload or payload.get("type") != "reset":
        raise HTTPException(status_code=400, detail="This reset link is invalid or has expired.")

    user = db.query(User).filter(User.id == payload["sub"]).first()
    if not user:
        raise HTTPException(status_code=400, detail="This reset link is invalid or has expired.")

    if len(body.password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters")

    user.hashed_password = hash_password(body.password)
    # Completing a reset proves email ownership, so mark verified too.
    user.is_verified = True
    db.commit()
    return {"message": "Password updated. You can now sign in."}


@router.post("/google", response_model=TokenResponse)
def google_login(body: GoogleAuthRequest, db: Session = Depends(get_db)):
    """Sign in with Google using an ID token from Google Identity Services."""
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=503, detail="Google OAuth not configured")

    try:
        from google.oauth2 import id_token
        from google.auth.transport import requests as grequests
    except ImportError:
        raise HTTPException(status_code=500, detail="Google auth library not installed")

    try:
        idinfo = id_token.verify_oauth2_token(
            body.id_token,
            grequests.Request(),
            GOOGLE_CLIENT_ID,
            clock_skew_in_seconds=10,
        )
    except ValueError as e:
        raise HTTPException(status_code=401, detail=f"Invalid Google token: {str(e)}")

    google_id = idinfo.get("sub")
    email = idinfo.get("email")
    full_name = idinfo.get("name", "")

    if not google_id or not email:
        raise HTTPException(status_code=400, detail="Invalid token: missing google_id or email")

    # Find existing user by google_id
    user = db.query(User).filter(User.google_id == google_id).first()

    if not user:
        # Try to find by email to link existing accounts
        user = db.query(User).filter(User.email == email).first()
        if user:
            # Link existing email account to Google
            user.google_id = google_id
            db.commit()
        else:
            # Create new user - generate unique username from email prefix
            base = email.split("@")[0]
            username = base
            n = 1
            while db.query(User).filter(User.username == username).first():
                username = f"{base}{n}"
                n += 1

            user = User(
                email=email,
                username=username,
                hashed_password=None,  # Google users don't have passwords
                full_name=full_name,
                google_id=google_id,
                is_active=True,
                is_verified=True,  # Google already verified the email
                scans_this_month=0,
                scan_reset_date=datetime.utcnow(),
            )
            db.add(user)
            db.commit()
            db.refresh(user)

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account disabled")

    return TokenResponse(
        access_token=create_access_token(user.id),
        refresh_token=create_refresh_token(user.id),
        user=user_to_dict(user, db),
    )


@router.get("/me")
def get_me(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return user_to_dict(current_user, db)


@router.put("/me")
def update_me(
    body: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if "full_name" in body:
        current_user.full_name = body["full_name"]
    if "username" in body:
        existing = db.query(User).filter(User.username == body["username"]).first()
        if existing and existing.id != current_user.id:
            raise HTTPException(status_code=400, detail="Username already taken")
        current_user.username = body["username"]
    db.commit()
    db.refresh(current_user)
    return user_to_dict(current_user, db)




class ApiKeyRequest(BaseModel):
    api_key: str


@router.put("/api-key")
def set_api_key(
    body: ApiKeyRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Legacy single-key endpoint - kept for backward compatibility."""
    api_key = body.api_key.strip() if body.api_key else None
    current_user.gemini_api_key = api_key
    db.commit()
    return {"success": True, "message": "API key saved" if api_key else "API key removed"}


# ── Multi-key endpoints ──────────────────────────────────────────────────────

def _key_to_dict(k: UserApiKey) -> dict:
    hours_until_reset = None
    if k.quota_exhausted_at:
        from datetime import timezone
        elapsed = (datetime.utcnow() - k.quota_exhausted_at).total_seconds()
        remaining = max(0, 86400 - elapsed)  # 24h window
        hours_until_reset = round(remaining / 3600, 1)

    return {
        "id": k.id,
        "label": k.label,
        "key_preview": f"...{k.api_key[-4:]}",
        "api_key": k.api_key,
        "is_active": bool(k.is_active),
        # Kept for API compatibility. Quota failures are never persisted locally.
        "quota_exhausted": False,
        "hours_until_reset": None,
        "created_at": k.created_at.isoformat() if k.created_at else "",
    }


@router.get("/api-keys")
def list_api_keys(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    keys = db.query(UserApiKey).filter(UserApiKey.user_id == current_user.id).order_by(UserApiKey.created_at).all()
    return {"keys": [_key_to_dict(k) for k in keys]}


class AddKeyRequest(BaseModel):
    api_key: str
    label: str = "My Key"


class UpdateKeyRequest(BaseModel):
    label: str = None
    api_key: str = None


@router.post("/api-keys")
def add_api_key(body: AddKeyRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    api_key = body.api_key.strip()
    if not api_key:
        raise HTTPException(status_code=400, detail="API key is required.")

    count = db.query(UserApiKey).filter(UserApiKey.user_id == current_user.id).count()
    if count >= 20:
        raise HTTPException(status_code=400, detail="Maximum of 20 API keys allowed.")

    key = UserApiKey(
        user_id=current_user.id,
        label=body.label.strip() or "My Key",
        api_key=api_key,
        is_active=count == 0,  # Auto-activate if first key
    )
    db.add(key)
    db.commit()
    db.refresh(key)
    return _key_to_dict(key)


@router.delete("/api-keys/{key_id}")
def delete_api_key(key_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    key = db.query(UserApiKey).filter(UserApiKey.id == key_id, UserApiKey.user_id == current_user.id).first()
    if not key:
        raise HTTPException(status_code=404, detail="Key not found")
    db.delete(key)
    db.commit()
    return {"success": True}


@router.put("/api-keys/{key_id}/activate")
def activate_api_key(key_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    keys = db.query(UserApiKey).filter(UserApiKey.user_id == current_user.id).all()
    target = next((k for k in keys if k.id == key_id), None)
    if not target:
        raise HTTPException(status_code=404, detail="Key not found")
    for k in keys:
        k.is_active = (k.id == key_id)
    db.commit()
    return {"success": True}


@router.put("/api-keys/{key_id}")
def update_api_key(
    key_id: str,
    body: UpdateKeyRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    key = db.query(UserApiKey).filter(UserApiKey.id == key_id, UserApiKey.user_id == current_user.id).first()
    if not key:
        raise HTTPException(status_code=404, detail="Key not found")

    if body.label is not None:
        key.label = body.label.strip()

    if body.api_key is not None:
        api_key = body.api_key.strip()
        if not api_key:
            raise HTTPException(status_code=400, detail="API key is required.")
        key.api_key = api_key

    db.commit()
    return _key_to_dict(key)
